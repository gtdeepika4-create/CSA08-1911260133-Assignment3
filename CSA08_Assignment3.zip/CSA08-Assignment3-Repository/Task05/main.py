"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import random,time,statistics,sys
def loop(values):
    c=[]; f=[]
    for x in values:
        if -50<=x<=50: c.append(x); f.append(x*9/5+32)
    return c,f
def comprehension(values):
    return ([x for x in values if -50<=x<=50],
            [x*9/5+32 for x in values if -50<=x<=50])
def map_filter(values):
    valid=filter(lambda x:-50<=x<=50,values)
    c=list(map(lambda x:x,valid))
    valid2=filter(lambda x:-50<=x<=50,values)
    f=list(map(lambda x:x*9/5+32,valid2))
    return c,f
def main():
    readings=[5,9,-70,4,12,30,7]
    c,f=loop(readings)
    alarms=[minute for minute,x in enumerate(readings) if x<2 or x>8]
    print("Valid C:",c); print("Valid F:",f); print("Alarm minute indices:",alarms)
    assert loop(readings)==comprehension(readings)==map_filter(readings)
    print("All-valid:",comprehension([3,4,5])); print("All-invalid:",comprehension([60,70,-80]))
    print("Dictionary comprehension:",{i:x for i,x in enumerate(readings) if -50<=x<=50})
    print("Set comprehension:",{x for x in readings if -50<=x<=50})
    for n in (10000,100000,1000000):
        data=[random.uniform(-60,60) for _ in range(n)]
        def bench(fn):
            ts=[]
            for _ in range(3):
                t=time.perf_counter(); fn(data); ts.append(time.perf_counter()-t)
            return statistics.median(ts)
        print("n, loop, comprehension, map/filter:",n,*[f"{bench(fn):.6f}" for fn in (loop,comprehension,map_filter)])
    valid_list=[x for x in readings if -50<=x<=50]
    gen=(x for x in readings if -50<=x<=50)
    print("Shallow bytes list/generator:",sys.getsizeof(valid_list),sys.getsizeof(gen))
if __name__=="__main__": main()
