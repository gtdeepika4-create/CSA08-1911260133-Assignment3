"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import re,time,statistics,random
def normalize_phone(phone):
    digits=re.sub(r"\D","",phone or "")
    if digits.startswith("91") and len(digits)==12: digits=digits[2:]
    return digits
def merge_contacts(records):
    merged={}
    for c in records:
        phone=normalize_phone(c.get("phone",""))
        email=(c.get("email") or "").strip().lower()
        name=(c.get("name") or "Unknown").strip()
        # A normalized phone is the primary identity. If absent, use normalized name fallback.
        key=("phone",phone) if phone else ("name",re.sub(r"\W+","",name.lower()))
        item=merged.setdefault(key,{"name":name,"phones":set(),"emails":set()})
        if c.get("phone"): item["phones"].add(phone)
        if email: item["emails"].add(email)
    return list(merged.values())
def main():
    contacts=[
      {"name":"Dr. Ravi","phone":"+91 98400 12345","email":"RAVI@EXAMPLE.COM"},
      {"name":"ravi kumar","phone":"9840012345","email":"ravi@example.com"},
      {"name":"Anu","phone":"9876543210","email":""},
      {"name":"Missing phone","email":"none@example.com"}]
    result=merge_contacts(contacts)
    print("Merged:",result)
    print("Groups:",len(result))
    assert normalize_phone("+91 98400 12345")==normalize_phone("9840012345")
    assert len(result)==3
    for n in (1000,100000):
        data=[{"name":f"Person{i%max(1,n//2)}","phone":f"+91 {9000000000+i%max(1,n//2)}","email":f"u{i}@example.com"} for i in range(n)]
        ts=[]
        for _ in range(3):
            t=time.perf_counter(); merge_contacts(data); ts.append(time.perf_counter()-t)
        print("n, dictionary_merge_s:",n,f"{statistics.median(ts):.6f}")
    print("Limitation: contacts sharing a phone are merged; people with no phone rely on name fallback and may be mis-grouped.")
if __name__=="__main__": main()
