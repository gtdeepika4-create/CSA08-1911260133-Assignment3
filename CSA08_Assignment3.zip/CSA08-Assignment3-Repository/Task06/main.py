"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import random,time,statistics,sys
def sample_timetable(n):
    stations=[f"Station-{i}" for i in range(100)]
    days={"Mon","Tue","Wed","Thu","Fri"}
    tt={}
    for i in range(n):
        stops=[]
        start=(i*7)%1440
        for j in range(3):
            minute=(start+j*35)%1440
            stops.append((stations[(i+j*13)%100],f"{minute//60:02d}:{minute%60:02d}",f"{(minute+3)//60%24:02d}:{(minute+3)%60:02d}"))
        tt[str(10000+i)]={"name":f"Train-{i}","stops":stops,"days":days if i%4 else {"Sat","Sun"}}
    return tt
def query(tt,station,day):
    result=[]
    for no,tr in tt.items():
        if day in tr["days"]:
            for st,arr,dep in tr["stops"]:
                if st==station: result.append((no,tr["name"],dep))
    return sorted(result,key=lambda row:row[2])
def main():
    timetable={
      "12601":{"name":"Chennai Express","stops":[("Chennai","05:00","05:10"),("Vijayawada","10:00","10:05"),("Hyderabad","15:00","15:10")],"days":{"Mon","Wed","Fri"}},
      "12602":{"name":"Coastal Express","stops":[("Chennai","06:00","06:15"),("Nellore","09:00","09:05"),("Vijayawada","12:00","12:10")],"days":{"Tue","Thu"}},
      "12603":{"name":"Southern Mail","stops":[("Madurai","04:00","04:05"),("Trichy","07:00","07:05"),("Chennai","11:00","11:10")],"days":{"Mon","Tue","Wed","Thu","Fri"}},
      "12604":{"name":"Hill Passenger","stops":[("Chennai","08:00","08:10"),("Katpadi","10:00","10:05"),("Bengaluru","13:00","13:10")],"days":{"Sat","Sun"}},
      "12605":{"name":"Delta Express","stops":[("Thanjavur","05:00","05:05"),("Trichy","06:00","06:05"),("Chennai","09:00","09:10")],"days":{"Mon","Wed","Fri"}}}
    print("Neat timetable:")
    for no,tr in timetable.items(): print(no,tr["name"],"; ".join(f"{s} {a}/{d}" for s,a,d in tr["stops"]),sorted(tr["days"]))
    print("Chennai Monday:",query(timetable,"Chennai","Mon"))
    print("Unknown station:",query(timetable,"Atlantis","Mon"))
    print("Train not running Tuesday (12601):", "Tue" in timetable["12601"]["days"])
    for n in (100,1000,10000):
        tt=sample_timetable(n); idx={}
        for no,tr in tt.items():
            for st,a,dep in tr["stops"]:
                idx.setdefault(st,[]).append((no,tr["name"],dep,tr["days"]))
        station="Station-1"; day="Mon"
        def indexed():
            return sorted([(no,name,dep) for no,name,dep,days in idx.get(station,[]) if day in days],key=lambda x:x[2])
        t=time.perf_counter(); plain=query(tt,station,day); a=time.perf_counter()-t
        t=time.perf_counter(); fast=indexed(); b=time.perf_counter()-t
        print("trains/plain_s/indexed_s/index_shallow_bytes:",n,f"{a:.6f}",f"{b:.6f}",sys.getsizeof(idx))
        assert plain==fast
if __name__=="__main__": main()
