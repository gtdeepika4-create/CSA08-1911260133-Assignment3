"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import random,time,statistics
def main():
    ai={"192311001","192311004","192311007","192311009"}
    iot={"192311002","192311004","192311009","192311010"}
    all_students={f"1923110{i:02d}" for i in range(1,11)}
    both=ai & iot; exactly_one=ai ^ iot; neither=all_students-(ai|iot)
    print("clash      :",sorted(both)); print("exactly one:",sorted(exactly_one)); print("neither    :",sorted(neither))
    assert both==ai.intersection(iot)
    assert exactly_one==ai.symmetric_difference(iot)
    assert neither==all_students.difference(ai.union(iot))
    print("Set-method equivalence: PASS")
    print("Venn regions: overlap=clash; two exclusive circle regions=exactly one; outside both=neither.")
    for n in (10000,100000,1000000):
        values=list(range(n)); s=set(values); target=n-1
        ts=[]
        for _ in range(5):
            t=time.perf_counter(); target in values; ts.append(time.perf_counter()-t)
        list_t=statistics.median(ts)
        ts=[]
        for _ in range(5):
            t=time.perf_counter(); target in s; ts.append(time.perf_counter()-t)
        print("n/list_s/set_s:",n,f"{list_t:.8f}",f"{statistics.median(ts):.8f}")
    print("Empty/identical tests:",set()&set(), {"a","b"}&{"a","b"})
if __name__=="__main__": main()
