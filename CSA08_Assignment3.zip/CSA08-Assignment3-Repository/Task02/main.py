"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import copy, sys, time, statistics
def main():
    rows,cols=3,4
    bad=[[0]*cols]*rows; bad[0][1]=7
    good=[[0 for _ in range(cols)] for _ in range(rows)]; good[0][1]=7
    print("bad :",bad); print("good:",good)
    print(bad[0] is bad[1],good[0] is good[1])
    stops={(13.0827,80.2707):"Chennai Central",(13.0418,80.2341):"T. Nagar"}
    for (lat,lon),name in stops.items(): print(lat,lon,name)
    try: {[13.0,80.0]:"invalid"}
    except TypeError as e: print("List key error:",type(e).__name__)
    original=[[1,2],[3,4]]
    shallow=copy.copy(original); sliced=original[:]; deep=copy.deepcopy(original)
    shallow[0][0]=99
    print("Aliasing:",bad[0] is bad[1],"shallow shares nested row:",shallow[0] is original[0],"deep independent:",deep[0] is original[0])
    mixed=(1,[2,3]); mixed[1].append(4); print("Mutable item inside tuple:",mixed)
    values=list(range(1_000_000)); tup=tuple(values)
    print("Container bytes list/tuple:",sys.getsizeof(values),sys.getsizeof(tup))
    def median(fn):
        xs=[]
        for _ in range(3):
            t=time.perf_counter(); fn(); xs.append(time.perf_counter()-t)
        return statistics.median(xs)
    print("Create seconds list/tuple:",median(lambda:list(range(1_000_000))),median(lambda:tuple(range(1_000_000))))
    print("Index seconds list/tuple:",median(lambda:[values[i] for i in range(0,10000,10)]),median(lambda:[tup[i] for i in range(0,10000,10)]))
    sparse={(0,1):7,(2,3):4}; print("Sparse zone dictionary:",sparse,"missing zone defaults to",sparse.get((1,1),0))
if __name__=="__main__": main()
