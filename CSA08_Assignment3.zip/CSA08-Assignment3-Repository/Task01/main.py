"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import random, time, statistics
def naive_avg(a, k=7):
    return [sum(a[i:i+k])/k for i in range(len(a)-k+1)]
def running_avg(a, k=7):
    if len(a)<k: return []
    total=sum(a[:k]); out=[total/k]
    for i in range(k,len(a)):
        total += a[i]-a[i-k]; out.append(total/k)
    return out
def timed(fn, data, repeats=3):
    vals=[]
    for _ in range(repeats):
        t=time.perf_counter(); fn(data); vals.append(time.perf_counter()-t)
    return statistics.median(vals)
def main():
    random.seed(42)
    readings=[random.randint(0,30) for _ in range(365)]
    weeks=[sum(readings[i:i+7]) for i in range(0,len(readings),7)]
    print("Weekly totals (last group may be partial):", weeks)
    print("Wettest week:", max(enumerate(weeks,1),key=lambda x:x[1]))
    print("Driest week:", min(enumerate(weeks,1),key=lambda x:x[1]))
    print("7-day moving averages (first 5):", running_avg(readings)[:5])
    print("Dry-day indices:", [i for i,x in enumerate(readings) if x==0])
    print("readings[7:14], readings[-7:], readings[::7]:", readings[7:14], readings[-7:], readings[::7][:5])
    assert naive_avg([])==[] and naive_avg([1,2,3])==[]
    print("Short-input tests: PASS")
    print("n, naive_s, running_s")
    for n in (365,36500,365000):
        a=[random.randint(0,30) for _ in range(n)]
        assert naive_avg(a)==running_avg(a)
        print(n, f"{timed(naive_avg,a):.6f}", f"{timed(running_avg,a):.6f}")
    print("Complexity: naive O(7n)=O(n); running sum O(n); both output O(n), running state O(1).")
if __name__=="__main__": main()
