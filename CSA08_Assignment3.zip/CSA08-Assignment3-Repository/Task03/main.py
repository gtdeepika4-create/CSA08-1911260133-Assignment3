"""
CSA08 Assignment 3 task source.
Run from this folder with: python main.py
"""

import re, random, time, statistics
from collections import Counter
STOP={"not","high","the","a","is","and","to","of"}
def frequencies(texts,stop):
    counts={}
    for text in texts:
        for word in re.findall(r"\b[\w]+\b",text.lower()):
            if word not in stop: counts[word]=counts.get(word,0)+1
    return counts
def top(counts,k):
    return sorted(counts.items(),key=lambda item:(-item[1],item[0]))[:k]
def main():
    calls=["seeds not received seeds delayed","fertiliser price high","seeds price high subsidy not received"]
    counts=frequencies(calls,{"not","high"})
    print("Top:",top(counts,3))
    complaints=[("Rice","Chennai","seed issue"),("Cotton","Madurai","water"),("Rice","Chennai","fertiliser")]
    by_district={}; by_crop={}
    for crop,district,text in complaints:
        by_district.setdefault(district,[]).append(text)
        by_crop.setdefault(crop,[]).append(text)
    print("By district:",by_district); print("By crop:",by_crop)
    assert top(counts,3)==[("seeds",3),("price",2),("received",2)]
    print("Empty/punctuation/case tests:",frequencies(["","SEEDS, seeds!"],set()))
    def bench(n):
        data=[random.choice(["seeds price high","water seeds delayed","crop issue"]) for _ in range(n)]
        words=[w for s in data for w in re.findall(r"\b[\w]+\b",s.lower())]
        distinct=set(words)
        def run(fn):
            ts=[]
            for _ in range(3):
                t=time.perf_counter(); fn(); ts.append(time.perf_counter()-t)
            return statistics.median(ts)
        a=run(lambda:frequencies(data,set()))
        b=run(lambda:{w:words.count(w) for w in distinct})
        c=run(lambda:Counter(words))
        return a,b,c
    for n in (1000,10000,100000): print("n, dict, list.count, Counter:",n,*[f"{x:.6f}" for x in bench(n)])
if __name__=="__main__": main()
